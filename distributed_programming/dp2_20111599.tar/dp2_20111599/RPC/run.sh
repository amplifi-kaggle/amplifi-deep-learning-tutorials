#!/bin/sh
./dp2_20111599_p1_client csblade02.sogang.ac.kr 3
